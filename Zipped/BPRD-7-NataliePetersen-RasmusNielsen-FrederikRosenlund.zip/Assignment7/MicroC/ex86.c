void main(int n) {
    int res;

    switch (n) {
        case 0:
            { res = 9999; }
        case 1:
            { res = 2; }
    }
    print res;
}