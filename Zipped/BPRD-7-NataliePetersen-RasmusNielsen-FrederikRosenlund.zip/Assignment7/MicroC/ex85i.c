void main() {
    int i; i = 1;
    int y; y = 4;
    int res;
    
    res = (y > i) ? y : i;
    print res;
}