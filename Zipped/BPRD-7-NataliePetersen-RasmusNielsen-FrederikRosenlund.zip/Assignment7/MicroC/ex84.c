void main() {
  int i;
  i = 20000000;
  while (i) {
    --i;
  }
}