void main(int n) { 
    ++n;
    print n;
    println;
    --n;
    print n;
    println;
}