// micro-C example 8 -- loop 20 million times

void main() {
  int i;
  i = 20000000;
  while (i) {
    i = i - 1;
  }
}
