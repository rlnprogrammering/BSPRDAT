(* Exercise 5.1 A *)
let merge (list1, list2) : int list =
    list1 @ list2 |> List.sort;;

let ex1 = merge ([3;5;12], [2;3;4;7]);;

(* Exercise 5.1 B *)
// see program.java

(* Exercise 5.7 *)
// see TypeInference.fs

(* Exercise 6.4 *)
// (we would love comprehensive feedback on this)
// 6_4_i.png
// 6_4_ii.heic

(* Exercises 6.1 6.2 6.3 6.5 *)
// see ParseAndRunHigher.fs

