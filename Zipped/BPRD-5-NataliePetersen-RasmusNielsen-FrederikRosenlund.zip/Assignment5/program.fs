(* Exercise 5.1 A *)
let merge (list1, list2) : int list =
    list1 @ list2 |> List.sort;;

let ex1 = merge ([3;5;12], [2;3;4;7]);;

(* Exercise 5.1 B *)
// see program.java

(* Exercise 5.7 *)
// <insert rule tree here>??

(* Exercises 6.1 6.2 6.3 6.4 6.5 *)
// see ParseAndRunHigher.fs

